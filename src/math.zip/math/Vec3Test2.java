package math;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Vec3Test2 {

	@Test
	void testVec3() {
		fail("Not yet implemented");
	}

	@Test
	void testVec3DoubleDoubleDouble() {
		fail("Not yet implemented");
	}

	@Test
	void testCross() {
		fail("Not yet implemented");
	}

	@Test
	void testSet() {
		fail("Not yet implemented");
	}

	@Test
	void testSetZero() {
		fail("Not yet implemented");
	}

	@Test
	void testVadd() {
		fail("Not yet implemented");
	}

	@Test
	void testVsub() {
		fail("Not yet implemented");
	}

	@Test
	void testNormalize() {
		fail("Not yet implemented");
	}

	@Test
	void testUnit() {
		fail("Not yet implemented");
	}

	@Test
	void testLength() {
		fail("Not yet implemented");
	}

	@Test
	void testLengthSquared() {
		fail("Not yet implemented");
	}

	@Test
	void testDistanceTo() {
		fail("Not yet implemented");
	}

	@Test
	void testDistanceSquared() {
		fail("Not yet implemented");
	}

	@Test
	void testScale() {
		fail("Not yet implemented");
	}

	@Test
	void testVmul() {
		fail("Not yet implemented");
	}

	@Test
	void testAddScaledVector() {
		fail("Not yet implemented");
	}

	@Test
	void testDot() {
		fail("Not yet implemented");
	}

	@Test
	void testIsZero() {
		fail("Not yet implemented");
	}

	@Test
	void testNegate() {
		fail("Not yet implemented");
	}

	@Test
	void testTangents() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

	@Test
	void testToArray() {
		fail("Not yet implemented");
	}

	@Test
	void testCopy() {
		fail("Not yet implemented");
	}

	@Test
	void testLerp() {
		fail("Not yet implemented");
	}

	@Test
	void testAlmostEqualsVec3() {
		fail("Not yet implemented");
	}

	@Test
	void testAlmostEqualsVec3Double() {
		fail("Not yet implemented");
	}

	@Test
	void testAlmostZero() {
		fail("Not yet implemented");
	}

	@Test
	void testAlmostZeroDouble() {
		fail("Not yet implemented");
	}

	@Test
	void testIsAntiparallelTo() {
		fail("Not yet implemented");
	}

	@Test
	void testClone() {
		fail("Not yet implemented");
	}

}
