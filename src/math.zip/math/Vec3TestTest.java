package math;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Vec3TestTest {

	@Test
	void testTestConstruct() {
		fail("Not yet implemented");
	}

	@Test
	void testTestCross() {
		fail("Not yet implemented");
	}

	@Test
	void testTestSet() {
		fail("Not yet implemented");
	}

	@Test
	void testTestSetZero() {
		fail("Not yet implemented");
	}

	@Test
	void testTestVadd() {
		fail("Not yet implemented");
	}

	@Test
	void testTestVsub() {
		fail("Not yet implemented");
	}

	@Test
	void testTestNormalize() {
		fail("Not yet implemented");
	}

	@Test
	void testTestNormalizeZero() {
		fail("Not yet implemented");
	}

	@Test
	void testTestUnit() {
		fail("Not yet implemented");
	}

	@Test
	void testTestUnitZero() {
		fail("Not yet implemented");
	}

	@Test
	void testTestLength() {
		fail("Not yet implemented");
	}

	@Test
	void testTestLengthSquared() {
		fail("Not yet implemented");
	}

	@Test
	void testTestDistanceTo() {
		fail("Not yet implemented");
	}

	@Test
	void testTestDistanceSquared() {
		fail("Not yet implemented");
	}

	@Test
	void testTestScale() {
		fail("Not yet implemented");
	}

	@Test
	void testTestVmul() {
		fail("Not yet implemented");
	}

	@Test
	void testTestAddScaledVector() {
		fail("Not yet implemented");
	}

	@Test
	void testTestDot() {
		fail("Not yet implemented");
	}

	@Test
	void testTestIsZero() {
		fail("Not yet implemented");
	}

	@Test
	void testTestNegate() {
		fail("Not yet implemented");
	}

	@Test
	void testTestTangents() {
		fail("Not yet implemented");
	}

	@Test
	void testTestToString() {
		fail("Not yet implemented");
	}

	@Test
	void testTestToArray() {
		fail("Not yet implemented");
	}

	@Test
	void testTestCopy() {
		fail("Not yet implemented");
	}

	@Test
	void testTestLerp() {
		fail("Not yet implemented");
	}

	@Test
	void testTestAlmostEquals() {
		fail("Not yet implemented");
	}

	@Test
	void testTestAlmostZero() {
		fail("Not yet implemented");
	}

	@Test
	void testTestIsAntiparallelTo() {
		fail("Not yet implemented");
	}

	@Test
	void testTestClone() {
		fail("Not yet implemented");
	}

}
